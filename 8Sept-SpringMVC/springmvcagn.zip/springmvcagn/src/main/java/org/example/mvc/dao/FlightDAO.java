package org.example.mvc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.example.mvc.entity.Flight;
import org.example.mvc.entity.Passengers;
import org.example.mvc.entity.User;
import org.springframework.stereotype.Repository;

@Repository
public class FlightDAO {
	
	private static int index = 200;
	
	private static String url = "jdbc:mysql://localhost:3306/Gainsight";
	public List<Flight> searchFlights(String source, String destination) {
		System.out.println("Here");
		List<Flight> allFlights = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url,"root","Bh@rgav2811");
			pst = conn.prepareStatement("select * from flight where source=? and destination=?");
			pst.setString(1, source);
			pst.setString(2, destination);
			
			rs = pst.executeQuery();
			while(rs.next()) {
				allFlights.add(new Flight(rs.getString(1),rs.getString(2), rs.getString(3), rs.getDouble(4), rs.getInt(5)));
				
			}
			System.out.println(allFlights.size());
			
				
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(rs!=null) rs.close();
				if(pst!=null) pst.close();
				if(conn!=null) conn.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return allFlights;
	}
	
	public Flight getFlightById(String flightId) {
		Flight f = null;
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs=null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url,"root","Bh@rgav2811");
			pst = conn.prepareStatement("select * from Flight where flight_id = ?");
			pst.setString(1, flightId);
			
			
			rs = pst.executeQuery();
			if(rs.next())
				f = new Flight(rs.getString(1),rs.getString(2),rs.getString(3),rs.getDouble(4),rs.getInt(5));
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(rs!=null) rs.close();
				if(pst!=null) pst.close();
				if(conn!=null) conn.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
			
		return f;
	}
	
	public boolean bookFlight(String flightId, Passengers passenger, String travelDate) {
		System.out.println("Here in book");
		Connection conn = null;
		Connection conn2 = null;
		PreparedStatement pst = null;
		PreparedStatement pst2 = null;
		int count=0, count1 = 0;
		String bookingId = "B" + index;
		index = index + 1;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url,"root","Bh@rgav2811");
			pst = conn.prepareStatement("insert into passengers values(?,?,?,?,?)");
			pst.setString(1, passenger.getPassengerId());
			pst.setString(2, passenger.getFirstName());
			pst.setString(3, passenger.getLastName());
			pst.setLong(4, passenger.getMobile());
			pst.setString(5, passenger.getEmail());
			
			count = pst.executeUpdate();
			System.out.println("Exceuted one");
			
			Class.forName("com.mysql.jdbc.Driver");
			conn2 = DriverManager.getConnection(url,"root","Bh@rgav2811");
			pst2 = conn2.prepareStatement("insert into bookings values(?,?,?,?)");
			pst2.setString(1, bookingId);
			pst2.setString(2, flightId);
			pst2.setString(3, passenger.getPassengerId());
			pst2.setString(4, travelDate);
			count1 = pst2.executeUpdate();
			
			System.out.println("Exceuted two");
			
				
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(pst!=null) pst.close();
				if(pst2!=null) pst2.close();
				if(conn!=null) conn.close();
				if(conn2!=null) conn2.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return count==1 && count1==1;
	}
	
	
}
