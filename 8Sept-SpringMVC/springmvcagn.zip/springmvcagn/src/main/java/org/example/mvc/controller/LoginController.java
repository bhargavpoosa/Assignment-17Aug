package org.example.mvc.controller;

import org.example.mvc.dao.UserDAO;
import org.example.mvc.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController
{
	@Autowired
	UserDAO userDAO;
	
	@GetMapping("/loginPage")
	public String getLoginPage()
	{
		return "Login";
	}
	
	@PostMapping("/validation")
	public String authenticateUser(@RequestParam("username")String username, @RequestParam("password")String password, Model model) {
		String message = "Invalid Username / Password ...Try Again...!";
		String msg = "Welcome";
		User user = new User(username,password);
		if(userDAO.authenticateUser(user)) {
			model.addAttribute("msg",msg);
			return "SearchFlights";
		}
		model.addAttribute("message",message);
		return "Error";
	}
}