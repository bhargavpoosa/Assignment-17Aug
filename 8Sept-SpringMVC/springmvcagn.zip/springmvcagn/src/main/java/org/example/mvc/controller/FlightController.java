package org.example.mvc.controller;

import java.util.Date;
import java.util.List;

import org.example.mvc.dao.FlightDAO;
import org.example.mvc.entity.Flight;
import org.example.mvc.entity.Passengers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class FlightController {
	
	@Autowired
	FlightDAO flightDAO;
	
	@PostMapping("/searchFlights")
	public String searchFlights(@RequestParam("source")String source, @RequestParam("destination")String destination, Model model) {
		List<Flight> allFlights = flightDAO.searchFlights(source,destination);
		model.addAttribute("flightlist",allFlights);
		return "FlightBooking";
		
	}
	
	@PostMapping("/book")
	public String bookFlight(@RequestParam("flightId")String flightId,@RequestParam("passengerId") String passengerId,@RequestParam("firstname") String firstName,@RequestParam("lastname") String lastName,@RequestParam("mobile") long mobile,@RequestParam("email") String email,@RequestParam("traveldate") String travelDate, Model model) {
		Passengers p = new Passengers(passengerId, firstName, lastName, mobile, email);
		String msg = "Something went wrong";
		if(flightDAO.bookFlight(flightId,p,travelDate))
		{
			Flight f = flightDAO.getFlightById(flightId);
			model.addAttribute("FlightObj",f);
			model.addAttribute("PassengerObj",p);
			return "Confirmation";
		}
		
		model.addAttribute("message",msg);
		return "Error";
	}
	
}
